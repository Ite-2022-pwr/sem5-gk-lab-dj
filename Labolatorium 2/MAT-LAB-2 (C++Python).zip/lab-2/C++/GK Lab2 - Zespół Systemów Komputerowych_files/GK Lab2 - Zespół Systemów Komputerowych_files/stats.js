<!--
var began_loading = (new Date()).getTime();
function stats(id) {
	document.images['stat'].src = '/zsk/img/stat.gif?id=' + id + '&width=' + screen.width + '&height=' + screen.height + '&depth=' + screen.colorDepth + '&load_time=' + (((new Date()).getTime() - began_loading) / 1000);
}
// -->
